const toggleBtn = document.getElementById("toggleBtn");
const body = document.body;

// Tugma bosilganda tema o'zgartirish
toggleBtn.addEventListener("click", () => {
    body.dataset.theme = body.dataset.theme === "dark" ? "light" : "dark";
    updateButtonText();
});

// Tugma matnini yangilash
function updateButtonText() {
    const isDarkMode = body.dataset.theme === "dark";
    toggleBtn.textContent = isDarkMode ? "☀️ Kun Rejimi" : "🌙 Tun Rejimi";
}

// LocalStorage-dan tema holatini o'qish (qo'shimcha)
if (localStorage.getItem("theme")) {
    body.dataset.theme = localStorage.getItem("theme");
    updateButtonText();
}

// LocalStorage-ga tema holatini saqlash
body.addEventListener("change", () => {
    localStorage.setItem("theme", body.dataset.theme);
});